"""
    This file is part of the Basata backup software.

    Basata is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Basata is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Basata.  If not, see <http://www.gnu.org/licenses/>.

Copyright 2018 by Michael Burns
    
"""


import socket
import getpass
import stat
import paramiko
from paramiko.py3compat import input



#import paramiko
#k = paramiko.RSAKey.from_private_key_file("/Users/whatever/Downloads/mykey.pem")
#c = paramiko.SSHClient()
#c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#print "connecting"
#c.connect( hostname = "www.acme.com", username = "ubuntu", pkey = k )
#print "connected"
#commands = [ "/home/ubuntu/firstscript.sh", "/home/ubuntu/secondscript.sh" ]
#for command in commands:
#	print "Executing {}".format( command )
#	stdin , stdout, stderr = c.exec_command(command)
#	print stdout.read()
#	print( "Errors")
#	print stderr.read()
#c.close()


KEYDISPATCHLIST = {'RSA': paramiko.RSAKey, 'DSS': paramiko.DSSKey}



class sftp_interface:

   def __init__(self):
      self.config_values = {'port': 22,'keytype':'RSA','keylength': 2048,'keyfile':'None'}
      self.sftp_conn = None
      pass

   def prepare(self, config_params = {}):
      self.config_values.update(config_params)


   def connect(self):
      host_key = None
      private_key = None
      password = None
      username = self.config_values['username']
      hostname = socket.gethostbyname(self.config_values['hostname'])  #socket.getfqdn()
      t = paramiko.Transport((self.config_values['hostname'],int(self.config_values['port'])))
      if self.config_values['keyfile']!='None':   #Perform key authentication
         if self.config_values['keytype'] not in KEYDISPATCHLIST:
            raise IOError
         private_key = KEYDISPATCHLIST[self.config_values['keytype']].from_private_key(self.config_values['keyfile'])
         t.connect(host_key, username, password, private_key)
      else:
         password = getpass.getpass('Connecting to %s@%s.  Enter Password: ' % (self.config_values['username'], self.config_values['hostname']))
         t.connect(host_key, username, password, gss_host=hostname, gss_auth = False, gss_kex = False)
      self.sftp_conn = paramiko.SFTPClient.from_transport(t)

   def generate_key_files(self):
      password = getpass.getpass('Generating Keys for %s@%s.  Enter Password: ' % (self.config_values['username'], self.config_values['hostname']))
      keyfilename = self.config_values['keyfile']
      keytype = self.config_values['keytype']
      if keytype in KEYDISPATCHLIST:
         private_key = KEYDISPATCHLIST[keytype].generate(self.config_values['keylength'])
         private_key.write_private_key_file(keyfilename, password=password)
         public_key = KEYDISPATCHLIST[keytype](filename = keyfilename, password=password)
         with open("%s.pub" % keyfilename, 'w') as fh:
            fh.write("%s %s" % (public_key.get_name(), public_key.get_base64()))
            fh.write(" %s" % ("Hello there",))
      else:
         pass
         


   def disconnect(self):
      self.sftp_conn.close()

   def type(self):
      return 'remote'

   def does_url_exist(self,file_name):
      flag = True
      try:
         file_stat_attr = self.sftp_conn.stat(file_name)
      except:
         flag = False
      return flag
      #return os.path.exists(file_name)
   
   def abspath(self,file_url):
      return file_url
   
   def list_directory(self,file_url):
      return self.sftp_conn.listdir(file_url)
   
   def join_url(self,base_url,operand):
      return (base_url + '/' + operand)
   
   def is_file_url(self,file_url):
      file_stat_attr = self.sftp_conn.stat(file_url)
      kind = stat.S_IFMT(file_stat_attr.st_mode)
      if kind == stat.S_IFREG:
         return True
      else:
         return False
      #return os.path.isfile(file_url)
   
   def is_dir_url(self,file_url):
      file_stat_attr = self.sftp_conn.stat(file_url)
      kind = stat.S_IFMT(file_stat_attr.st_mode)
      if kind == stat.S_IFDIR:
         return True
      else:
         return False
   
   def put_file(self,from_url,to_url):  #
      self.sftp_conn.put(from_url, to_url)
      
   def get_file(self,from_url,to_url):
      self.sftp_conn.get(from_url, to_url)
      
   def remove_directory(self,file_url):
      self.sftp_conn.rmdir(file_url)
      
   def remove_file(self,file_url):
      self.sftp_conn.remove(file_url)
      
   def create_directory(self,file_url):
      self.sftp_conn.mkdir(file_url)
      

   def set_file_dates(self,file_url,access_date,modified_date):
      date_tuple = (access_date,modified_date)
      self.sftp_conn.utime(file_url,date_tuple)

   def get_modified_date(self,file_url):
      file_stat_attr = self.sftp_conn.stat(file_url)
      return int(file_stat_attr.st_mtime)
      #for stat_name in file_stat_attr.keys():
      #   print stat_name, ": ", file_stat_attr[stat_name]
      #return file_stat_attr['st_mtime']

   def get_access_date(self,file_url):
      file_stat_attr = self.sftp_conn.stat(file_url)
      return int(file_stat_attr.st_atime)

def main():
   sftp_inst = sftp_interface()
   sftp_inst.prepare({'hostname': 'd0gbert-laptop', 'username': 'd0gbert', 'port': 2222})
   sftp_inst.connect()
   curr_dir = '.'
   print("Listing Directory: %s" % (curr_dir,))
   print(sftp_inst.list_directory(curr_dir))
   curr_dir = sftp_inst.join_url(curr_dir,'programming')
   print("Listing Directory: %s" % (curr_dir,))
   print(sftp_inst.list_directory(curr_dir))
   print(sftp_inst.does_url_exist(sftp_inst.join_url(curr_dir,'test.c')))
   print(sftp_inst.does_url_exist(sftp_inst.join_url(curr_dir,'dude')))   
   print(sftp_inst.is_dir_url(sftp_inst.join_url(curr_dir,'svn')))
   print(sftp_inst.is_file_url(sftp_inst.join_url(curr_dir,'svn')))
   print(sftp_inst.get_modified_date(sftp_inst.join_url(curr_dir,'test.asm')))
   
   sftp_inst.disconnect()



#Traceback (most recent call last):
#  File "basata_sftp_interface.py", line 193, in <module>
#    generate_keyfiles()
#  File "basata_sftp_interface.py", line 189, in generate_keyfiles
#    sftp_inst.generate_key_files()
#  File "basata_sftp_interface.py", line 85, in generate_key_files
#    private_key.write_private_key(keyfilename, password=password)
#  File "/Library/Python/2.7/site-packages/paramiko/rsakey.py", line 148, in write_private_key
#    password=password
#  File "/Library/Python/2.7/site-packages/paramiko/pkey.py", line 364, in _write_private_key
#    f.write(key.private_bytes(
#AttributeError: 'str' object has no attribute 'write'




def generate_keyfiles():
   sftp_inst = sftp_interface()
   sftp_inst.prepare({'hostname': 'd0gbert-laptop', 'username': 'd0gbert', 'port': 2222, 'keyfile': 'devbox_login.key'})
   sftp_inst.generate_key_files()
   
   
if __name__ == '__main__':
   generate_keyfiles()
